G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.1*
G04 #@! TF.CreationDate,2025-05-02T09:37:06-05:00*
G04 #@! TF.ProjectId,GuacSolder,47756163-536f-46c6-9465-722e6b696361,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.1) date 2025-05-02 09:37:06*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.440000*%
%ADD11R,1.270000X5.080000*%
%ADD12C,17.800000*%
%ADD13C,1.600000*%
%ADD14O,1.600000X1.600000*%
%ADD15R,1.800000X1.100000*%
%ADD16RoundRect,0.275000X-0.625000X0.275000X-0.625000X-0.275000X0.625000X-0.275000X0.625000X0.275000X0*%
%ADD17R,1.700000X1.700000*%
%ADD18C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,RV1*
X142500000Y-96000000D03*
X139960000Y-93460000D03*
X137420000Y-96000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,BT1*
X128515000Y-79000000D03*
X150485000Y-79000000D03*
D12*
X139500000Y-79000000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,R2*
X124500000Y-75190000D03*
D14*
X124500000Y-82810000D03*
G04 #@! TD*
D15*
G04 #@! TO.C,Q1*
X155600000Y-77500000D03*
D16*
X157670000Y-78770000D03*
X155600000Y-80040000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,R1*
X138230000Y-52500000D03*
X140770000Y-52500000D03*
G04 #@! TD*
D17*
G04 #@! TO.C,M1*
X139500000Y-60000000D03*
D18*
X139500000Y-62540000D03*
G04 #@! TD*
M02*
